8 kHz, 16-bit mono. One file per key, 0.4 s each.
